import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const String supabaseUrl = 'https://zoycbbhkfwrpbbsjqbwm.supabase.co';
const String supabasePublishableKey = 'sb_publishable_5KUj8DlrsQCru23Q0uwfXw_9FjLd2GZ';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: supabaseUrl,
    publishableKey: supabasePublishableKey,
  );
  runApp(const PlannerApp());
}

const cream = Color(0xFFFCFAF2);
const paper = Color(0xFFFFFEFB);
const beige = Color(0xFFD8CDB8);
const graphite = Color(0xFF45433F);
const muted = Color(0xFF99958D);
const green = Color(0xFF778675);
const buttonColor = Color(0xFFE2C7C0);

enum TaskType {
  video,
  shooting,
  ordinary,
}

Color taskColor(TaskType type) {
  switch (type) {
    case TaskType.video:
      return const Color(0xFFF2C6D0);
    case TaskType.shooting:
      return const Color(0xFFB9D8EE);
    case TaskType.ordinary:
      return const Color(0xFFF3E3A9);
  }
}

String taskTypeName(TaskType type) {
  switch (type) {
    case TaskType.video:
      return 'Публикация видео';
    case TaskType.shooting:
      return 'Съёмка';
    case TaskType.ordinary:
      return 'Обычная задача';
  }
}

IconData taskTypeIcon(TaskType type) {
  switch (type) {
    case TaskType.video:
      return Icons.video_library_outlined;
    case TaskType.shooting:
      return Icons.camera_alt_outlined;
    case TaskType.ordinary:
      return Icons.check_circle_outline;
  }
}


class CustomTaskCategory {
  CustomTaskCategory({
    required this.id,
    required this.name,
    required this.colorValue,
    this.icon = '✨',
    this.imageBase64,
  });

  String id;
  String name;
  int colorValue;
  String icon;
  String? imageBase64;

  Color get color => Color(colorValue);

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'colorValue': colorValue,
    'icon': icon, 'imageBase64': imageBase64,
  };

  factory CustomTaskCategory.fromJson(Map<String, dynamic> json) =>
      CustomTaskCategory(
        id: json['id']?.toString() ?? DateTime.now().microsecondsSinceEpoch.toString(),
        name: json['name']?.toString() ?? 'Моя категория',
        colorValue: json['colorValue'] as int? ?? 0xFFE2C7C0,
        icon: json['icon']?.toString() ?? '✨',
        imageBase64: json['imageBase64']?.toString(),
      );
}

class PlannerTask {
  PlannerTask({
    required this.title,
    required this.date,
    required this.time,
    this.notes = '',
    this.done = false,
    this.type = TaskType.ordinary,
    List<DateTime>? dates,
    this.categoryId,
  }) : dates = dates ?? <DateTime>[date];

  String title;
  DateTime date;
  TimeOfDay time;
  String notes;
  bool done;
  TaskType type;
  List<DateTime> dates;
  String? categoryId;

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'date': date.toIso8601String(),
      'dates': dates.map((d) => d.toIso8601String()).toList(),
      'hour': time.hour,
      'minute': time.minute,
      'notes': notes,
      'done': done,
      'type': type.name,
      'categoryId': categoryId,
    };
  }

  factory PlannerTask.fromJson(Map<String, dynamic> json) {
    final savedType = json['type'] as String?;
    final type = TaskType.values.firstWhere(
      (item) => item.name == savedType,
      orElse: () => TaskType.ordinary,
    );

    return PlannerTask(
      title: json['title'] as String? ?? '',
      date: DateTime.parse(json['date'] as String),
      time: TimeOfDay(
        hour: json['hour'] as int? ?? 9,
        minute: json['minute'] as int? ?? 0,
      ),
      notes: json['notes'] as String? ?? '',
      done: json['done'] as bool? ?? false,
      type: type,
      categoryId: json['categoryId']?.toString(),
      dates: (json['dates'] as List?)?.map((d) => DateTime.parse(d.toString())).toList() ?? <DateTime>[DateTime.parse(json['date'] as String)],
    );
  }
}


enum HabitFrequency { daily, weekly, monthly }

String frequencyLabel(HabitFrequency frequency) {
  switch (frequency) {
    case HabitFrequency.daily: return 'Ежедневно';
    case HabitFrequency.weekly: return 'Еженедельно';
    case HabitFrequency.monthly: return 'Ежемесячно';
  }
}

class ProgressItem {
  ProgressItem({required this.title, this.progress = 0, List<GoalStep>? steps})
      : steps = steps ?? <GoalStep>[];
  String title;
  int progress; // legacy field; goal progress is now calculated from steps.
  final List<GoalStep> steps;
  int get calculatedProgress => steps.isEmpty
      ? 0
      : ((steps.where((step) => step.done).length / steps.length) * 100).round();
  Map<String, dynamic> toJson() => {
    'title': title,
    'progress': progress,
    'steps': steps.map((step) => step.toJson()).toList(),
  };
  factory ProgressItem.fromJson(dynamic value) {
    if (value is String) return ProgressItem(title: value);
    final map = Map<String, dynamic>.from(value as Map);
    return ProgressItem(
      title: map['title']?.toString() ?? '',
      progress: (((map['progress'] as num?)?.toInt() ?? 0).clamp(0, 100)).toInt(),
      steps: (map['steps'] as List? ?? [])
          .map((e) => GoalStep.fromJson(e)).toList(),
    );
  }
}

class GoalStep {
  GoalStep({required this.title, this.done = false});
  String title;
  bool done;
  Map<String, dynamic> toJson() => {'title': title, 'done': done};
  factory GoalStep.fromJson(dynamic value) {
    final map = Map<String, dynamic>.from(value as Map);
    return GoalStep(title: map['title']?.toString() ?? '',
        done: map['done'] as bool? ?? false);
  }
}

class PlannerHabit {
  PlannerHabit({required this.title, this.frequency = HabitFrequency.daily, this.weekday = DateTime.monday, this.monthDay = 1, Set<String>? completedPeriods}) : completedPeriods = completedPeriods ?? <String>{};
  String title;
  HabitFrequency frequency;
  int weekday;
  int monthDay;
  Set<String> completedPeriods;
  Map<String, dynamic> toJson() => {'title': title, 'frequency': frequency.name, 'weekday': weekday, 'monthDay': monthDay, 'completedPeriods': completedPeriods.toList()};
  factory PlannerHabit.fromJson(String key, dynamic value) {
    if (value is bool) {
      final now = DateTime.now();
      final today = 'd:${now.year}-${now.month}-${now.day}';
      return PlannerHabit(title: key, completedPeriods: value ? <String>{today} : <String>{});
    }
    final map = Map<String, dynamic>.from(value as Map);
    final name = map['frequency'] as String?;
    final frequency = HabitFrequency.values.firstWhere((e) => e.name == name, orElse: () => HabitFrequency.daily);
    return PlannerHabit(title: map['title']?.toString() ?? key, frequency: frequency, weekday: (map['weekday'] as num?)?.toInt() ?? DateTime.monday, monthDay: (map['monthDay'] as num?)?.toInt() ?? 1, completedPeriods: (map['completedPeriods'] as List? ?? []).map((e) => e.toString()).toSet());
  }
}

class PlannerApp extends StatelessWidget {
  const PlannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mon Planner',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(
          seedColor: graphite,
          primary: graphite,
          onPrimary: paper,
          surface: cream,
          onSurface: graphite,
        ).copyWith(
          secondary: buttonColor,
          onSecondary: graphite,
        ),
        textTheme: ThemeData.light().textTheme.apply(
          bodyColor: graphite,
          displayColor: graphite,
        ),
        iconTheme: const IconThemeData(color: graphite),
        appBarTheme: const AppBarTheme(
          backgroundColor: cream,
          foregroundColor: graphite,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
        fontFamily: 'Arial',
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, snapshot) {
        final session = Supabase.instance.client.auth.currentSession;
        if (session == null) return const AuthPage();
        return const PlannerPage();
      },
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool isLogin = true;
  bool isBusy = false;
  bool obscurePassword = true;
  bool staySignedIn = true;
  String? message;
  String? error;

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    if (email.isEmpty || password.length < 6) {
      setState(() => error = 'Укажи email и пароль не короче 6 символов.');
      return;
    }
    setState(() { isBusy = true; error = null; message = null; });
    try {
      if (isLogin) {
        await Supabase.instance.client.auth.signInWithPassword(
          email: email,
          password: password,
        );
        TextInput.finishAutofillContext(shouldSave: staySignedIn);
      } else {
        final response = await Supabase.instance.client.auth.signUp(
          email: email,
          password: password,
        );
        if (response.session == null) {
          setState(() => message = 'Аккаунт создан. Проверь почту и подтверди регистрацию, затем войди.');
        }
      }
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'Не удалось выполнить запрос. Проверь интернет и настройки Supabase.');
      debugPrint('Auth error: $e');
    } finally {
      if (mounted) setState(() => isBusy = false);
    }
  }

  Future<void> resetPassword() async {
    final email = emailController.text.trim();
    if (email.isEmpty) {
      setState(() => error = 'Сначала введи email.');
      return;
    }
    setState(() { isBusy = true; error = null; message = null; });
    try {
      await Supabase.instance.client.auth.resetPasswordForEmail(email);
      setState(() => message = 'Если адрес зарегистрирован, на него придёт письмо для сброса пароля.');
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'Не удалось отправить письмо. Попробуй ещё раз.');
      debugPrint('Password reset error: $e');
    } finally {
      if (mounted) setState(() => isBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: cream,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Container(
                padding: const EdgeInsets.all(26),
                decoration: BoxDecoration(
                  color: paper,
                  borderRadius: BorderRadius.circular(26),
                  border: Border.all(color: beige.withValues(alpha: .65)),
                ),
                child: AutofillGroup(
                  child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.calendar_month_rounded, size: 42, color: graphite),
                    const SizedBox(height: 14),
                    const Text('MON PLANNER', textAlign: TextAlign.center,
                      style: TextStyle(color: graphite, fontSize: 19, letterSpacing: 4, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Text(isLogin ? 'Войди в свой аккаунт' : 'Создай аккаунт',
                      textAlign: TextAlign.center, style: const TextStyle(color: muted, fontSize: 14)),
                    const SizedBox(height: 28),
                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      autofillHints: const [AutofillHints.email],
                      decoration: InputDecoration(labelText: 'Email', filled: true, fillColor: cream,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller: passwordController,
                      obscureText: obscurePassword,
                      autofillHints: isLogin ? const [AutofillHints.password] : const [AutofillHints.newPassword],
                      decoration: InputDecoration(labelText: 'Пароль', filled: true, fillColor: cream,
                        suffixIcon: IconButton(icon: Icon(obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                          onPressed: () => setState(() => obscurePassword = !obscurePassword)),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
                    ),
                    if (isLogin)
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        dense: true,
                        controlAffinity: ListTileControlAffinity.leading,
                        activeColor: green,
                        value: staySignedIn,
                        onChanged: (value) => setState(() => staySignedIn = value ?? true),
                        title: const Text('Оставаться в системе', style: TextStyle(color: graphite, fontSize: 13)),
                      ),
                    if (error != null) ...[
                      const SizedBox(height: 12),
                      Text(error!, style: const TextStyle(color: Colors.redAccent, fontSize: 13)),
                    ],
                    if (message != null) ...[
                      const SizedBox(height: 12),
                      Text(message!, style: const TextStyle(color: green, fontSize: 13)),
                    ],
                    const SizedBox(height: 20),
                    SizedBox(height: 52, child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: buttonColor, foregroundColor: graphite,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
                      onPressed: isBusy ? null : submit,
                      child: isBusy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: paper))
                        : Text(isLogin ? 'Войти' : 'Зарегистрироваться'),
                    )),
                    if (isLogin)
                      TextButton(onPressed: isBusy ? null : resetPassword, child: const Text('Забыли пароль?')),
                    const SizedBox(height: 4),
                    TextButton(
                      onPressed: isBusy ? null : () => setState(() { isLogin = !isLogin; error = null; message = null; }),
                      child: Text(isLogin ? 'Создать новый аккаунт' : 'Уже есть аккаунт? Войти', style: const TextStyle(color: graphite)),
                    ),
                  ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class PlannerPage extends StatefulWidget {
  const PlannerPage({super.key});

  @override
  State<PlannerPage> createState() => _PlannerPageState();
}

class _PlannerPageState extends State<PlannerPage> {
  int mode = 0;
  int currentTab = 1; // 0 — главная, 1 — календарь, 3 — заметки
  int homeSection = 0; // цели, достижения, привычки
  ProgressItem? openedGoal;
  DateTime selectedDate = DateTime.now();
  final List<PlannerTask> tasks = [];
  final List<CustomTaskCategory> customCategories = [];
  final Set<String> hiddenBuiltinCategories = {};
  static const Map<String, IconData> categoryOutlineIcons = {
    'sport': Icons.fitness_center_outlined, 'food': Icons.restaurant_outlined,
    'money': Icons.account_balance_wallet_outlined, 'meeting': Icons.groups_outlined,
    'camera': Icons.photo_camera_outlined, 'shopping': Icons.shopping_bag_outlined,
    'work': Icons.laptop_mac_outlined, 'heart': Icons.favorite_border,
    'travel': Icons.flight_outlined, 'learning': Icons.menu_book_outlined,
    'home': Icons.home_outlined, 'other': Icons.auto_awesome_outlined,
  };
  final Map<String, String> dailyNotes = {};
  final List<ProgressItem> goals = [];
  final List<ProgressItem> achievements = [];
  final Map<String, PlannerHabit> habits = {};
  static const Color habitBlue = Color(0xFFAFCBE8);
  final Map<String, List<String>> noteTopics = {};
  String? selectedNoteTopic;
  bool isLoading = true;
  final TextEditingController profileNameController = TextEditingController();
  final TextEditingController profileNicknameController = TextEditingController();
  final TextEditingController profileAgeController = TextEditingController();
  bool profileSaving = false;

  static const String tasksStorageKey = 'mon_planner_tasks_v1';
  static const String notesStorageKey = 'mon_planner_notes_v1';
  static const String homeStorageKey = 'mon_planner_home_v1';
  static const String topicsStorageKey = 'mon_planner_topics_v1';
  static const String categoriesStorageKey = 'mon_planner_categories_v1';
  static const String hiddenCategoriesStorageKey = 'mon_planner_hidden_builtin_categories_v1';

  final List<String> months = [
    'Январь', 'Февраль', 'Март', 'Апрель',
    'Май', 'Июнь', 'Июль', 'Август',
    'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];

  final List<String> weekdays = [
    'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'
  ];

  @override
  void initState() {
    super.initState();
    _loadProfileFields();
    loadData();
  }

  void _loadProfileFields() {
    final metadata = Supabase.instance.client.auth.currentUser?.userMetadata ?? {};
    profileNameController.text = metadata['full_name']?.toString() ?? '';
    profileNicknameController.text = metadata['nickname']?.toString() ?? '';
    profileAgeController.text = metadata['age']?.toString() ?? '';
  }

  @override
  void dispose() {
    profileNameController.dispose();
    profileNicknameController.dispose();
    profileAgeController.dispose();
    super.dispose();
  }

  Future<void> _saveProfile() async {
    final name = profileNameController.text.trim();
    final nickname = profileNicknameController.text.trim();
    final ageText = profileAgeController.text.trim();
    if (nickname.isEmpty) {
      _showProfileMessage('Придумай никнейм — он будет отображаться в названии приложения.');
      return;
    }
    if (ageText.isNotEmpty && int.tryParse(ageText) == null) {
      _showProfileMessage('Возраст нужно указать числом.');
      return;
    }
    setState(() => profileSaving = true);
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(data: {
        'full_name': name,
        'nickname': nickname,
        'age': ageText,
      }));
      if (mounted) {
        setState(() {});
        _showProfileMessage('Профиль сохранён.');
      }
    } on AuthException catch (e) {
      _showProfileMessage(e.message);
    } catch (e) {
      _showProfileMessage('Не удалось сохранить профиль. Проверь подключение.');
      debugPrint('Profile save error: $e');
    } finally {
      if (mounted) setState(() => profileSaving = false);
    }
  }

  void _showProfileMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _showChangeEmailDialog() async {
    final controller = TextEditingController(text: Supabase.instance.client.auth.currentUser?.email ?? '');
    final result = await showDialog<String>(context: context, builder: (dialogContext) => AlertDialog(
      backgroundColor: paper,
      title: const Text('Изменить почту'),
      content: TextField(controller: controller, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Новый email')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('Отправить подтверждение')),
      ],
    ));
    controller.dispose();
    if (result == null || result.isEmpty) return;
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(email: result));
      _showProfileMessage('Запрос отправлен. Проверь почту для подтверждения изменения адреса.');
    } on AuthException catch (e) { _showProfileMessage(e.message); }
    catch (e) { _showProfileMessage('Не удалось изменить почту.'); debugPrint('Email update error: $e'); }
  }

  Future<void> _showChangePasswordDialog() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(context: context, builder: (dialogContext) => AlertDialog(
      backgroundColor: paper,
      title: const Text('Изменить пароль'),
      content: TextField(controller: controller, obscureText: true, decoration: const InputDecoration(labelText: 'Новый пароль', helperText: 'Минимум 8 символов')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text), child: const Text('Изменить')),
      ],
    ));
    controller.dispose();
    if (result == null) return;
    if (result.length < 8) { _showProfileMessage('Пароль должен содержать минимум 8 символов.'); return; }
    try {
      await Supabase.instance.client.auth.updateUser(UserAttributes(password: result));
      _showProfileMessage('Пароль успешно изменён.');
    } on AuthException catch (e) { _showProfileMessage(e.message); }
    catch (e) { _showProfileMessage('Не удалось изменить пароль.'); debugPrint('Password update error: $e'); }
  }

  Widget _profileField(String label, TextEditingController controller, {String? hint, TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label, hintText: hint, filled: true, fillColor: cream,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  Widget buildProfilePage() {
    final user = Supabase.instance.client.auth.currentUser;
    return ListView(
      key: const ValueKey('profile-page'),
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(22), border: Border.all(color: beige.withValues(alpha: .65))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const CircleAvatar(radius: 34, backgroundColor: cream, child: Icon(Icons.person_outline_rounded, size: 36, color: graphite)),
            const SizedBox(height: 12),
            const Text('Мой профиль', textAlign: TextAlign.center, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w600, color: graphite)),
            const SizedBox(height: 5),
            Text(user?.email ?? '', textAlign: TextAlign.center, style: const TextStyle(color: muted, fontSize: 13)),
            const SizedBox(height: 24),
            _profileField('Имя', profileNameController, hint: 'Как тебя зовут?'),
            _profileField('Никнейм', profileNicknameController, hint: 'Например, Yura'),
            _profileField('Возраст', profileAgeController, hint: 'Необязательно', keyboardType: TextInputType.number),
            const SizedBox(height: 4),
            SizedBox(height: 50, child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: buttonColor, foregroundColor: graphite, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
              onPressed: profileSaving ? null : _saveProfile,
              child: profileSaving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: paper)) : const Text('Сохранить профиль'),
            )),
          ]),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(20), border: Border.all(color: beige.withValues(alpha: .65))),
          child: Column(children: [
            ListTile(leading: const Icon(Icons.alternate_email_rounded, color: graphite), title: const Text('Изменить почту'), subtitle: const Text('Потребуется подтверждение нового адреса'), trailing: const Icon(Icons.chevron_right), onTap: _showChangeEmailDialog),
            const Divider(height: 1, indent: 16, endIndent: 16, color: beige),
            ListTile(leading: const Icon(Icons.lock_outline_rounded, color: graphite), title: const Text('Изменить пароль'), trailing: const Icon(Icons.chevron_right), onTap: _showChangePasswordDialog),
          ]),
        ),
        const SizedBox(height: 16),
        TextButton.icon(onPressed: () async => Supabase.instance.client.auth.signOut(), icon: const Icon(Icons.logout_rounded), label: const Text('Выйти из аккаунта'), style: TextButton.styleFrom(foregroundColor: graphite)),
      ],
    );
  }

  Map<String, dynamic> _makePayload() => {
    'tasks': tasks.map((task) => task.toJson()).toList(),
    'customCategories': customCategories.map((category) => category.toJson()).toList(),
    'hiddenBuiltinCategories': hiddenBuiltinCategories.toList(),
    'dailyNotes': dailyNotes,
    'home': {
      'goals': goals.map((item) => item.toJson()).toList(),
      'achievements': achievements.map((item) => item.toJson()).toList(),
      'habits': habits.map((key, value) => MapEntry(key, value.toJson())),
    },
    'noteTopics': noteTopics,
  };

  void _applyPayload(Map<String, dynamic> payload) {
    tasks.clear();
    customCategories.clear();
    hiddenBuiltinCategories.clear();
    hiddenBuiltinCategories.addAll((payload['hiddenBuiltinCategories'] as List? ?? []).map((e) => e.toString()));
    dailyNotes.clear();
    goals.clear();
    achievements.clear();
    habits.clear();
    noteTopics.clear();

    for (final item in (payload['customCategories'] as List? ?? [])) {
      try { customCategories.add(CustomTaskCategory.fromJson(Map<String, dynamic>.from(item as Map))); }
      catch (e) { debugPrint('Не удалось загрузить категорию: $e'); }
    }
    for (final item in (payload['tasks'] as List? ?? [])) {
      try { tasks.add(PlannerTask.fromJson(Map<String, dynamic>.from(item as Map))); }
      catch (e) { debugPrint('Не удалось загрузить задачу: $e'); }
    }
    final notes = Map<String, dynamic>.from(payload['dailyNotes'] as Map? ?? {});
    notes.forEach((key, value) => dailyNotes[key] = value.toString());

    final home = Map<String, dynamic>.from(payload['home'] as Map? ?? {});
    goals.addAll((home['goals'] as List? ?? []).map((e) => ProgressItem.fromJson(e)));
    achievements.addAll((home['achievements'] as List? ?? []).map((e) => ProgressItem.fromJson(e)));
    final savedHabits = Map<String, dynamic>.from(home['habits'] as Map? ?? {});
    savedHabits.forEach((key, value) {
      final habit = PlannerHabit.fromJson(key, value);
      habits[habit.title] = habit;
    });

    final topics = Map<String, dynamic>.from(payload['noteTopics'] as Map? ?? {});
    topics.forEach((key, value) {
      noteTopics[key] = (value as List? ?? []).map((e) => e.toString()).toList();
    });
  }

  Future<void> _savePayloadLocally(SharedPreferences prefs, Map<String, dynamic> payload) async {
    await prefs.setString(tasksStorageKey, jsonEncode(payload['tasks']));
    await prefs.setString(notesStorageKey, jsonEncode(payload['dailyNotes']));
    await prefs.setString(homeStorageKey, jsonEncode(payload['home']));
    await prefs.setString(topicsStorageKey, jsonEncode(payload['noteTopics']));
    await prefs.setString(categoriesStorageKey, jsonEncode(payload['customCategories'] ?? []));
    await prefs.setString(hiddenCategoriesStorageKey, jsonEncode(payload['hiddenBuiltinCategories'] ?? []));
  }

  Future<Map<String, dynamic>> _readLocalPayload(SharedPreferences prefs) async {
    final savedTasks = prefs.getString(tasksStorageKey);
    final savedNotes = prefs.getString(notesStorageKey);
    final savedHome = prefs.getString(homeStorageKey);
    final savedTopics = prefs.getString(topicsStorageKey);
    final savedCategories = prefs.getString(categoriesStorageKey);
    final savedHiddenCategories = prefs.getString(hiddenCategoriesStorageKey);
    Map<String, dynamic> home = {};
    if (savedHome != null) home = Map<String, dynamic>.from(jsonDecode(savedHome) as Map);
    return {
      'tasks': savedTasks == null ? [] : jsonDecode(savedTasks),
      'dailyNotes': savedNotes == null ? {} : jsonDecode(savedNotes),
      'home': home,
      'noteTopics': savedTopics == null ? {} : jsonDecode(savedTopics),
      'customCategories': savedCategories == null ? [] : jsonDecode(savedCategories),
      'hiddenBuiltinCategories': savedHiddenCategories == null ? [] : jsonDecode(savedHiddenCategories),
    };
  }

  // При первом входе старые локальные данные переносятся только в первый аккаунт
  // на этом браузере. Последующие аккаунты не получат чужие записи.
  Future<void> loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final user = Supabase.instance.client.auth.currentUser;
    try {
      final localPayload = await _readLocalPayload(prefs);
      if (user == null) {
        _applyPayload(localPayload);
      } else {
        final remote = await Supabase.instance.client
            .from('planner_data')
            .select('payload')
            .eq('user_id', user.id)
            .maybeSingle();

        if (remote != null && remote['payload'] != null) {
          final cloudPayload = Map<String, dynamic>.from(remote['payload'] as Map);
          _applyPayload(cloudPayload);
          await _savePayloadLocally(prefs, cloudPayload);
          await prefs.setBool('mon_planner_legacy_migrated_v1', true);
        } else {
          final migrationDone = prefs.getBool('mon_planner_legacy_migrated_v1') ?? false;
          if (!migrationDone) {
            _applyPayload(localPayload);
            await Supabase.instance.client.from('planner_data').upsert({
              'user_id': user.id,
              'payload': localPayload,
              'updated_at': DateTime.now().toUtc().toIso8601String(),
            });
            await prefs.setBool('mon_planner_legacy_migrated_v1', true);
          } else {
            final emptyPayload = <String, dynamic>{
              'tasks': [], 'dailyNotes': {},
              'home': {'goals': [], 'achievements': [], 'habits': {}},
              'noteTopics': {},
            };
            _applyPayload(emptyPayload);
            await _savePayloadLocally(prefs, emptyPayload);
            await Supabase.instance.client.from('planner_data').upsert({
              'user_id': user.id,
              'payload': emptyPayload,
              'updated_at': DateTime.now().toUtc().toIso8601String(),
            });
          }
        }
      }
    } catch (e) {
      debugPrint('Ошибка облачной загрузки, пробуем локальные данные: $e');
      try { _applyPayload(await _readLocalPayload(prefs)); }
      catch (localError) { debugPrint('Ошибка локальной загрузки: $localError'); }
    }

    if (mounted) setState(() => isLoading = false);
  }

  // Сохраняем локальную копию и отправляем данные в личную облачную запись.
  Future<void> saveData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final payload = _makePayload();
      await _savePayloadLocally(prefs, payload);
      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        await Supabase.instance.client.from('planner_data').upsert({
          'user_id': user.id,
          'payload': payload,
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        });
      }
    } catch (e) {
      debugPrint('Ошибка сохранения данных в облако: $e');
    }
  }

  String dateKey(DateTime date) =>
      '${date.year}-${date.month}-${date.day}';

  String fullDate(DateTime date) =>
      '${date.day} ${months[date.month - 1].toLowerCase()} ${date.year}';

  bool sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  List<PlannerTask> tasksFor(DateTime date) {
    final result = tasks
        .where((task) => task.dates.any((d) => sameDay(d, date)))
        .toList();

    result.sort((a, b) {
      final aMinutes = a.time.hour * 60 + a.time.minute;
      final bMinutes = b.time.hour * 60 + b.time.minute;
      return aMinutes.compareTo(bMinutes);
    });

    return result;
  }


  CustomTaskCategory? categoryById(String? id) {
    if (id == null) return null;
    for (final category in customCategories) {
      if (category.id == id) return category;
    }
    return null;
  }

  Color colorForTask(PlannerTask task) =>
      categoryById(task.categoryId)?.color ?? taskColor(task.type);

  String labelForTask(PlannerTask task) =>
      categoryById(task.categoryId)?.name ?? taskTypeName(task.type);

  Widget categoryGlyph(CustomTaskCategory category, {double size = 24}) {
    if (category.imageBase64 != null && category.imageBase64!.isNotEmpty) {
      try {
        return ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: Image.memory(base64Decode(category.imageBase64!), width: size, height: size, fit: BoxFit.contain),
        );
      } catch (_) {}
    }
    final legacyIcons = {'🏋️':'sport','🍳':'food','💰':'money','🤝':'meeting','📸':'camera','🛍️':'shopping','💻':'work','❤️':'heart','✈️':'travel','📚':'learning','🏠':'home','✨':'other'};
    final icon = categoryOutlineIcons[category.icon] ?? categoryOutlineIcons[legacyIcons[category.icon]] ?? Icons.auto_awesome_outlined;
    return Icon(icon, size: size, color: graphite,);
  }

  Future<int?> _showFullColorPicker(int initialColor) async {
    int chosen = initialColor;
    final hexController = TextEditingController(
      text: initialColor.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase(),
    );
    final presets = <int>[
      0xFFF2D5D8, 0xFFF4DCC8, 0xFFF4E8B8, 0xFFDCE8C9,
      0xFFCDE4DF, 0xFFD2E3F2, 0xFFDED5EF, 0xFFEBD5E8,
      0xFFE7E1D8, 0xFFB9D8EE, 0xFFF2C6D0, 0xFFD8E4C5,
      0xFFF3E3A9, 0xFFD9C9E8, 0xFFE8D3B8, 0xFFC9DDE0,
    ];
    final result = await showDialog<int>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setPickerState) {
          final hsv = HSVColor.fromColor(Color(chosen));
          void updateColor(Color color) {
            setPickerState(() {
              chosen = color.value;
              hexController.text = color.value.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase();
            });
          }
          return AlertDialog(
            backgroundColor: paper,
            title: const Text('Выбор цвета'),
            content: SizedBox(
              width: 360,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 48,
                      decoration: BoxDecoration(color: Color(chosen), borderRadius: BorderRadius.circular(12), border: Border.all(color: beige)),
                    ),
                    const SizedBox(height: 16),
                    const Text('Рекомендованные пастельные'),
                    const SizedBox(height: 9),
                    Wrap(spacing: 9, runSpacing: 9, children: presets.map((value) => InkWell(
                      onTap: () => updateColor(Color(value)),
                      borderRadius: BorderRadius.circular(30),
                      child: Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(color: Color(value), shape: BoxShape.circle,
                          border: Border.all(color: chosen == value ? graphite : beige, width: chosen == value ? 2 : 1)),
                      ),
                    )).toList()),
                    const SizedBox(height: 18),
                    const Text('Любой цвет'),
                    Row(children: [
                      const SizedBox(width: 54, child: Text('Оттенок')),
                      Expanded(child: Slider(
                        min: 0, max: 360, value: hsv.hue,
                        onChanged: (v) => updateColor(hsv.withHue(v).toColor()),
                      )),
                    ]),
                    Row(children: [
                      const SizedBox(width: 54, child: Text('Яркость')),
                      Expanded(child: Slider(
                        min: 0, max: 1, value: hsv.saturation,
                        onChanged: (v) => updateColor(hsv.withSaturation(v).toColor()),
                      )),
                    ]),
                    Row(children: [
                      const SizedBox(width: 54, child: Text('Светлота')),
                      Expanded(child: Slider(
                        min: 0, max: 1, value: hsv.value,
                        onChanged: (v) => updateColor(hsv.withValue(v).toColor()),
                      )),
                    ]),
                    TextField(
                      controller: hexController,
                      maxLength: 6,
                      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9a-fA-F]'))],
                      decoration: const InputDecoration(labelText: 'HEX-код', prefixText: '#', counterText: ''),
                      onChanged: (value) {
                        if (value.length == 6) {
                          final parsed = int.tryParse(value, radix: 16);
                          if (parsed != null) setPickerState(() => chosen = 0xFF000000 | parsed);
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Отмена')),
              FilledButton(onPressed: () => Navigator.pop(dialogContext, chosen), child: const Text('Выбрать')),
            ],
          );
        },
      ),
    );
    hexController.dispose();
    return result;
  }

  Future<void> manageTaskCategories() async {
    final nameController = TextEditingController();
    const icons = ['sport','food','money','meeting','camera','shopping','work','heart','travel','learning','home','other'];
    const colors = [0xFFE9C9C9,0xFFB9D8EE,0xFFD8E4C5,0xFFF3E3A9,0xFFD9C9E8,0xFFE8D3B8,0xFFC9DDE0];
    String selectedIcon = 'other';
    int selectedColor = colors.first;
    String? imageData;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: paper,
          title: const Text('Мои категории'),
          content: SizedBox(
            width: 380,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ...TaskType.values.where((type) => !hiddenBuiltinCategories.contains(type.name)).map((type) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: taskColor(type).withValues(alpha: .35), borderRadius: BorderRadius.circular(12)), child: Icon(taskTypeIcon(type), color: graphite, size: 22)),
                    title: Text(type == TaskType.video ? 'Публикация' : type == TaskType.shooting ? 'Съёмка' : 'Обычная'),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { setState(() => hiddenBuiltinCategories.add(type.name)); await saveData(); setDialogState(() {}); }),
                  )),
                  if (customCategories.isNotEmpty)
                    ...customCategories.map((category) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: category.color.withValues(alpha: .35),
                        child: categoryGlyph(category, size: 25),
                      ),
                      title: Text(category.name),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          setState(() {
                            customCategories.remove(category);
                            for (final task in tasks) {
                              if (task.categoryId == category.id) task.categoryId = null;
                            }
                          });
                          await saveData();
                          setDialogState(() {});
                        },
                      ),
                    )),
                  if (hiddenBuiltinCategories.isNotEmpty) TextButton.icon(onPressed: () async { setState(() => hiddenBuiltinCategories.clear()); await saveData(); setDialogState(() {}); }, icon: const Icon(Icons.restore_outlined), label: const Text('Восстановить стандартные категории')),
                  const Divider(),
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Название категории'),
                  ),
                  const SizedBox(height: 12),
                  const Text('Иконка'),
                  const SizedBox(height: 6),
                  Wrap(spacing: 8, runSpacing: 8, children: List.generate(icons.length, (index) { final icon = icons[index]; return
                    InkWell(
                      onTap: () => setDialogState(() { selectedIcon = icon; imageData = null; }),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: selectedIcon == icon && imageData == null ? beige : cream,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: selectedIcon == icon && imageData == null ? graphite : beige),
                        ),
                        child: Icon(categoryOutlineIcons[icon] ?? Icons.auto_awesome_outlined, size: 22, color: graphite),
                      ),
                    ); }).toList()),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final result = await FilePicker.platform.pickFiles(
                        type: FileType.custom, allowedExtensions: ['png'], withData: true,
                      );
                      if (result != null && result.files.single.bytes != null) {
                        if (result.files.single.bytes!.length > 2 * 1024 * 1024) {
                          if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('PNG должна быть меньше 2 МБ')),
                          );
                        } else {
                          setDialogState(() => imageData = base64Encode(result.files.single.bytes!));
                        }
                      }
                    },
                    icon: const Icon(Icons.upload_file),
                    label: Text(imageData == null ? 'Загрузить свою PNG-иконку' : 'PNG загружена'),
                  ),
                  const SizedBox(height: 12),
                  const Text('Цвет категории'),
                  const SizedBox(height: 8),
                  Wrap(spacing: 9, runSpacing: 9, children: colors.map((value) => InkWell(
                    onTap: () => setDialogState(() => selectedColor = value),
                    borderRadius: BorderRadius.circular(30),
                    child: Container(
                      width: 30, height: 30,
                      decoration: BoxDecoration(
                        color: Color(value), shape: BoxShape.circle,
                        border: Border.all(color: selectedColor == value ? graphite : beige, width: selectedColor == value ? 2 : 1),
                      ),
                    ),
                  )).toList()),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final pickedColor = await _showFullColorPicker(selectedColor);
                      if (pickedColor != null) setDialogState(() => selectedColor = pickedColor);
                    },
                    icon: const Icon(Icons.palette_outlined),
                    label: const Text('Открыть полную палитру'),
                  ),
                  Row(children: [
                    Container(width: 22, height: 22, decoration: BoxDecoration(color: Color(selectedColor), shape: BoxShape.circle, border: Border.all(color: beige))),
                    const SizedBox(width: 8),
                    Text('#${selectedColor.toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}', style: const TextStyle(color: muted, fontSize: 12)),
                  ]),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Закрыть')),
            FilledButton(
              onPressed: () async {
                final name = nameController.text.trim();
                if (name.isEmpty) return;
                setState(() => customCategories.add(CustomTaskCategory(
                  id: DateTime.now().microsecondsSinceEpoch.toString(),
                  name: name, colorValue: selectedColor, icon: selectedIcon, imageBase64: imageData,
                )));
                await saveData();
                nameController.clear();
                setDialogState(() { imageData = null; selectedIcon = icons.last; });
              },
              child: const Text('Создать категорию'),
            ),
          ],
        ),
      ),
    );
    nameController.dispose();
  }

  void changeMode() {
    setState(() {
      mode = (mode + 1) % 3;
    });
  }

  void shiftDate(int amount) {
    setState(() {
      if (mode == 0) {
        selectedDate = selectedDate.add(Duration(days: amount));
      } else if (mode == 1) {
        selectedDate = selectedDate.add(Duration(days: amount * 7));
      } else {
        selectedDate = DateTime(
          selectedDate.year,
          selectedDate.month + amount,
          1,
        );
      }
    });
  }

  DateTime weekStart() {
    return selectedDate.subtract(
      Duration(days: selectedDate.weekday - 1),
    );
  }

  // ДОБАВЛЕНИЕ ЗАДАЧИ
  Future<void> addTask() async {
    final titleController = TextEditingController();
    final notesController = TextEditingController();
    TimeOfDay selectedTime = TimeOfDay.now();
    final selectedDates = <DateTime>[DateTime(selectedDate.year, selectedDate.month, selectedDate.day)];
    TaskType selectedType = TaskType.ordinary;
    String? selectedCategoryId;

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: paper,
              title: const Text('Новая задача'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ВЫБЕРИ ТИП ЗАДАЧИ',
                      style: TextStyle(
                        color: muted,
                        fontSize: 11,
                        letterSpacing: 1.4,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Wrap(spacing: 6, runSpacing: 6, children: [
                      ...TaskType.values.where((type) => !hiddenBuiltinCategories.contains(type.name)).map((type) => ChoiceChip(
                        avatar: Icon(taskTypeIcon(type), size: 19, color: graphite),
                        label: Text(type == TaskType.video ? 'Публикация' : type == TaskType.shooting ? 'Съёмка' : 'Обычная'),
                        selected: selectedCategoryId == null && selectedType == type,
                        selectedColor: taskColor(type).withValues(alpha: .4),
                        onSelected: (_) => setDialogState(() { selectedCategoryId = null; selectedType = type; }),
                      )),
                      ...customCategories.map((category) => ChoiceChip(
                        avatar: categoryGlyph(category, size: 19),
                        label: Text(category.name),
                        selected: selectedCategoryId == category.id,
                        selectedColor: category.color.withValues(alpha: .4),
                        onSelected: (_) => setDialogState(() => selectedCategoryId = category.id),
                      )),
                    ]),
                    Align(alignment: Alignment.centerLeft, child: TextButton.icon(
                      onPressed: () async {
                        Navigator.pop(dialogContext, false);
                        await manageTaskCategories();
                        if (mounted) addTask();
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Создать свою категорию'),
                    )),
                    const SizedBox(height: 18),
                    TextField(
                      controller: titleController,
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'Название задачи',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: notesController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Описание / заметки',
                        alignLabelWithHint: true,
                      ),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: selectedTime,
                        );
                        if (picked != null) {
                          setDialogState(() => selectedTime = picked);
                        }
                      },
                      icon: const Icon(Icons.access_time),
                      label: Text('Время: ${selectedTime.format(context)}'),
                    ),
                    Wrap(spacing: 6, runSpacing: 4, children: [
                      ...selectedDates.map((d) => Chip(label: Text(fullDate(d)), onDeleted: selectedDates.length > 1 ? () => setDialogState(() => selectedDates.remove(d)) : null)),
                      ActionChip(avatar: const Icon(Icons.add, size: 16), label: const Text('Добавить дату'), onPressed: () async {
                        final picked = await showDatePicker(context: context, initialDate: selectedDates.last, firstDate: DateTime(2020), lastDate: DateTime(2100));
                        if (picked != null && !selectedDates.any((d) => d.year == picked.year && d.month == picked.month && d.day == picked.day)) {
                          setDialogState(() => selectedDates.add(DateTime(picked.year, picked.month, picked.day)));
                        }
                      }),
                    ]),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, false),
                  child: const Text('Отмена'),
                ),
                FilledButton(
                  onPressed: () {
                    if (titleController.text.trim().isNotEmpty) {
                      Navigator.pop(dialogContext, true);
                    }
                  },
                  child: const Text('Добавить в календарь'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == true && titleController.text.trim().isNotEmpty) {
      setState(() {
        tasks.add(
          PlannerTask(
            title: titleController.text.trim(),
            date: selectedDates.first,
            dates: List<DateTime>.from(selectedDates),
            time: selectedTime,
            notes: notesController.text.trim(),
            type: selectedType,
            categoryId: selectedCategoryId,
          ),
        );
        currentTab = 1;
        mode = 0;
      });
      await saveData();
    }

    titleController.dispose();
    notesController.dispose();
  }

  String habitPeriodKey(PlannerHabit habit, DateTime date) {
    if (habit.frequency == HabitFrequency.daily) return 'd:${dateKey(date)}';
    if (habit.frequency == HabitFrequency.weekly) {
      final monday = date.subtract(Duration(days: date.weekday - 1));
      return 'w:${dateKey(monday)}';
    }
    return 'm:${date.year}-${date.month.toString().padLeft(2, '0')}';
  }

  bool habitDueOn(PlannerHabit habit, DateTime date) {
    if (habit.frequency == HabitFrequency.daily) return true;
    if (habit.frequency == HabitFrequency.weekly) return date.weekday == habit.weekday;
    return date.day == habit.monthDay;
  }

  bool habitDoneFor(PlannerHabit habit, DateTime date) => habit.completedPeriods.contains(habitPeriodKey(habit, date));

  Future<void> toggleHabit(PlannerHabit habit, DateTime date, bool value) async {
    final key = habitPeriodKey(habit, date);
    setState(() { if (value) { habit.completedPeriods.add(key); } else { habit.completedPeriods.remove(key); } });
    await saveData();
  }

  Future<void> toggleGoalStep(ProgressItem goal, GoalStep step, bool value) async {
    setState(() => step.done = value);
    if (goal.steps.isNotEmpty && goal.calculatedProgress == 100 && goals.contains(goal)) {
      setState(() {
        goals.remove(goal);
        if (!achievements.any((item) => item.title == goal.title)) {
          achievements.add(ProgressItem(title: goal.title));
        }
        openedGoal = null;
      });
    }
    await saveData();
  }

  Future<void> addGoalStep(ProgressItem goal) async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: paper,
        title: const Text('Новая задача для цели'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Что нужно сделать?'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Отмена')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text.trim().isNotEmpty),
            child: const Text('Добавить'),
          ),
        ],
      ),
    );
    if (result == true && controller.text.trim().isNotEmpty) {
      setState(() => goal.steps.add(GoalStep(title: controller.text.trim())));
      await saveData();
    }
    controller.dispose();
  }

  Future<void> editGoalStep(ProgressItem goal, GoalStep step) async {
    final controller = TextEditingController(text: step.title);
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: paper,
      title: const Text('Редактировать задачу'),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'Название задачи')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim().isNotEmpty), child: const Text('Сохранить')),
      ],
    ));
    if (ok == true && controller.text.trim().isNotEmpty) {
      setState(() => step.title = controller.text.trim());
      await saveData();
    }
    controller.dispose();
  }

  Future<void> deleteGoalStep(ProgressItem goal, GoalStep step) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: paper,
      title: const Text('Удалить задачу?'),
      content: Text('«${step.title}» будет удалена из цели.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить')),
      ],
    ));
    if (ok == true) {
      setState(() => goal.steps.remove(step));
      await saveData();
    }
  }

  Future<void> editHomeItem(String section, {ProgressItem? goal, PlannerHabit? habit}) async {
    final controller = TextEditingController(text: goal?.title ?? habit?.title ?? '');
    HabitFrequency selectedFrequency = habit?.frequency ?? HabitFrequency.daily;
    int selectedWeekday = habit?.weekday ?? DateTime.monday;
    int selectedMonthDay = habit?.monthDay ?? 1;
    final result = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        backgroundColor: paper,
        title: Text(section == 'goals' ? 'Редактировать цель' : 'Редактировать привычку'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'Название')),
          if (section == 'habits') ...[
            const SizedBox(height: 14),
            DropdownButtonFormField<HabitFrequency>(value: selectedFrequency,
              decoration: const InputDecoration(labelText: 'Повторять', border: OutlineInputBorder()),
              items: HabitFrequency.values.map((f) => DropdownMenuItem(value: f, child: Text(frequencyLabel(f)))).toList(),
              onChanged: (v) { if (v != null) setDialogState(() => selectedFrequency = v); }),
            if (selectedFrequency == HabitFrequency.weekly) ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: selectedWeekday,
                decoration: const InputDecoration(labelText: 'День недели', border: OutlineInputBorder()),
                items: const ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'].asMap().entries.map((e) => DropdownMenuItem(value: e.key + 1, child: Text(e.value))).toList(),
                onChanged: (v) { if (v != null) setDialogState(() => selectedWeekday = v); }),
            ],
            if (selectedFrequency == HabitFrequency.monthly) ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: selectedMonthDay,
                decoration: const InputDecoration(labelText: 'Число месяца', border: OutlineInputBorder()),
                items: List.generate(31, (i) => i + 1).map((d) => DropdownMenuItem(value: d, child: Text('$d число'))).toList(),
                onChanged: (v) { if (v != null) setDialogState(() => selectedMonthDay = v); }),
            ],
          ],
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim().isNotEmpty), child: const Text('Сохранить'))],
      ),
    ));
    if (result == true && controller.text.trim().isNotEmpty) {
      final newName = controller.text.trim();
      setState(() {
        if (goal != null) goal.title = newName;
        if (habit != null) {
          final oldKey = habits.keys.firstWhere((k) => identical(habits[k], habit), orElse: () => habit.title);
          habits.remove(oldKey);
          habit.title = newName;
          habit.frequency = selectedFrequency;
          habit.weekday = selectedWeekday;
          habit.monthDay = selectedMonthDay;
          habits[newName] = habit;
        }
      });
      await saveData();
    }
    controller.dispose();
  }

  Future<void> deleteHabit(PlannerHabit habit) async {
    setState(() { habits.removeWhere((key, value) => identical(value, habit)); });
    await saveData();
  }

  Future<void> addHomeItem(String section) async {
    final controller = TextEditingController();
    HabitFrequency selectedFrequency = HabitFrequency.daily;
    int selectedWeekday = DateTime.monday;
    int selectedMonthDay = 1;
    final title = section == 'goals' ? 'Новая цель' : section == 'achievements' ? 'Новое достижение' : 'Новая привычка';
    final result = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        backgroundColor: paper,
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'Напиши название...')),
          if (section == 'habits') ...[
            const SizedBox(height: 16),
            const Text('ПОВТОРЯТЬ', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            DropdownButtonFormField<HabitFrequency>(value: selectedFrequency, decoration: const InputDecoration(border: OutlineInputBorder()),
              items: HabitFrequency.values.map((f) => DropdownMenuItem(value: f, child: Text(frequencyLabel(f)))).toList(),
              onChanged: (value) { if (value != null) setDialogState(() => selectedFrequency = value); }),
            if (selectedFrequency == HabitFrequency.weekly) ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: selectedWeekday,
                decoration: const InputDecoration(labelText: 'День недели', border: OutlineInputBorder()),
                items: const ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'].asMap().entries.map((e) => DropdownMenuItem(value: e.key + 1, child: Text(e.value))).toList(),
                onChanged: (v) { if (v != null) setDialogState(() => selectedWeekday = v); }),
            ],
            if (selectedFrequency == HabitFrequency.monthly) ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                value: selectedMonthDay,
                decoration: const InputDecoration(labelText: 'Число месяца', border: OutlineInputBorder()),
                items: List.generate(31, (i) => i + 1).map((d) => DropdownMenuItem(value: d, child: Text('$d число'))).toList(),
                onChanged: (v) { if (v != null) setDialogState(() => selectedMonthDay = v); }),
            ],
          ],
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim().isNotEmpty), child: const Text('Добавить'))],
      ),
    ));
    if (result == true && controller.text.trim().isNotEmpty) {
      final name = controller.text.trim();
      if (section == 'goals') {
        // A goal is only created after the user has entered at least one step.
        final tasksController = TextEditingController();
        final tasksResult = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (tasksDialogContext) => StatefulBuilder(
            builder: (context, setTasksDialogState) => AlertDialog(
              backgroundColor: paper,
              title: const Text('Добавьте задачи для достижения цели'),
              content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Цель: $name', style: const TextStyle(color: muted, fontSize: 13)),
                const SizedBox(height: 12),
                const Text('Добавьте хотя бы одну задачу. Каждую задачу укажите с новой строки.'),
                const SizedBox(height: 10),
                TextField(
                  controller: tasksController,
                  autofocus: true,
                  minLines: 3,
                  maxLines: 6,
                  decoration: const InputDecoration(
                    hintText: 'Например:\nИзучить основы\nВыполнить первый проект',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (_) => setTasksDialogState(() {}),
                ),
              ]),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(tasksDialogContext, false),
                  child: const Text('Отмена'),
                ),
                FilledButton(
                  onPressed: tasksController.text.split('\n').any((line) => line.trim().isNotEmpty)
                      ? () => Navigator.pop(tasksDialogContext, true)
                      : null,
                  child: const Text('Создать цель'),
                ),
              ],
            ),
          ),
        );
        if (tasksResult == true) {
          final steps = tasksController.text
              .split('\n')
              .map((line) => line.trim())
              .where((line) => line.isNotEmpty)
              .map((line) => GoalStep(title: line))
              .toList();
          if (steps.isNotEmpty) {
            setState(() => goals.add(ProgressItem(title: name, steps: steps)));
            await saveData();
          }
        }
        tasksController.dispose();
      } else {
        setState(() {
          if (section == 'achievements') achievements.add(ProgressItem(title: name));
          else habits[name] = PlannerHabit(title: name, frequency: selectedFrequency, weekday: selectedWeekday, monthDay: selectedMonthDay);
        });
        await saveData();
      }
    }
    controller.dispose();
  }

  Future<void> addNoteTopic() async {
    final controller = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: paper,
        title: const Text('Новая тема'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Например: Работа, Идеи...'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              dialogContext,
              controller.text.trim().isNotEmpty,
            ),
            child: const Text('Создать'),
          ),
        ],
      ),
    );
    if (result == true && controller.text.trim().isNotEmpty) {
      setState(() {
        final name = controller.text.trim();
        noteTopics.putIfAbsent(name, () => []);
        selectedNoteTopic = name;
      });
      await saveData();
    }
    controller.dispose();
  }

  Future<void> editNoteTopic(String oldName) async {
    final controller = TextEditingController(text: oldName);
    final result = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: paper, title: const Text('Переименовать тему'),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'Название темы')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim().isNotEmpty), child: const Text('Сохранить'))],
    ));
    final newName = controller.text.trim();
    if (result == true && newName.isNotEmpty && newName != oldName) {
      setState(() {
        noteTopics[newName] = [...(noteTopics[oldName] ?? <String>[])];
        noteTopics.remove(oldName);
        if (selectedNoteTopic == oldName) selectedNoteTopic = newName;
      });
      await saveData();
    }
    controller.dispose();
  }

  Future<void> deleteNoteTopic(String topic) async {
    final confirmed = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: paper, title: const Text('Удалить тему?'),
      content: Text('Тема «$topic» и все заметки внутри неё будут удалены.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить'))],
    ));
    if (confirmed == true) {
      setState(() { noteTopics.remove(topic); if (selectedNoteTopic == topic) selectedNoteTopic = null; });
      await saveData();
    }
  }

  Future<void> editTopicNote(String topic, int index) async {
    final controller = TextEditingController(text: noteTopics[topic]![index]);
    final result = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: paper, title: const Text('Редактировать заметку'),
      content: TextField(controller: controller, autofocus: true, minLines: 4, maxLines: 9,
        decoration: const InputDecoration(labelText: 'Текст заметки', alignLabelWithHint: true)),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim().isNotEmpty), child: const Text('Сохранить'))],
    ));
    if (result == true && controller.text.trim().isNotEmpty) {
      setState(() => noteTopics[topic]![index] = controller.text.trim());
      await saveData();
    }
    controller.dispose();
  }

  Future<void> addTopicNote() async {
    final topic = selectedNoteTopic;
    if (topic == null) return;
    final titleController = TextEditingController();
    final bodyController = TextEditingController();
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: paper,
        title: const Text('Новая заметка'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                autofocus: true,
                decoration: const InputDecoration(labelText: 'Заголовок'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bodyController,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Текст заметки',
                  alignLabelWithHint: true,
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              dialogContext,
              titleController.text.trim().isNotEmpty ||
                  bodyController.text.trim().isNotEmpty,
            ),
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );
    if (result == true) {
      final title = titleController.text.trim();
      final body = bodyController.text.trim();
      setState(() {
        noteTopics[topic]!.add(
          title.isEmpty ? body : (body.isEmpty ? title : '$title\n$body'),
        );
      });
      await saveData();
    }
    titleController.dispose();
    bodyController.dispose();
  }

  Widget _homeSectionTitle(String title, VoidCallback onAdd) {
    return Padding(
      padding: const EdgeInsets.only(top: 22, bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title.toUpperCase(),
              style: const TextStyle(
                color: muted,
                fontSize: 11,
                letterSpacing: 1.8,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          IconButton(
            onPressed: onAdd,
            icon: const Icon(Icons.add_circle_outline, color: graphite),
            tooltip: 'Добавить',
          ),
        ],
      ),
    );
  }

  Widget buildHomePage() {
    if (openedGoal != null && goals.contains(openedGoal)) {
      return buildGoalDetail(openedGoal!);
    }
    final todayTasks = tasksFor(DateTime.now());
    final sections = ['Цели', 'Достижения', 'Привычки'];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        const Text('ТВОЯ ЖИЗНЬ — ТВОЙ ПЛАН',
            style: TextStyle(color: muted, fontSize: 10, letterSpacing: 2,
                fontWeight: FontWeight.w600)),
        const SizedBox(height: 7),
        const Text('Главная', style: TextStyle(color: graphite, fontSize: 28,
            fontWeight: FontWeight.w600)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: graphite, borderRadius: BorderRadius.circular(20)),
          child: Row(children: [
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Сегодня', style: TextStyle(color: beige, fontSize: 13)),
                SizedBox(height: 6),
                Text('Маленькие шаги ведут к большим результатам',
                    style: TextStyle(color: paper, fontSize: 17,
                        fontWeight: FontWeight.w600, height: 1.3)),
              ])),
            const SizedBox(width: 8),
            Column(children: [
              Text('${todayTasks.where((t) => t.done).length}/${todayTasks.length}',
                  style: const TextStyle(color: paper, fontSize: 25, fontWeight: FontWeight.bold)),
              const Text('задач', style: TextStyle(color: beige, fontSize: 11)),
            ]),
          ]),
        ),
        const SizedBox(height: 20),
        Row(children: List.generate(sections.length, (index) =>
          Expanded(child: Padding(
            padding: EdgeInsets.only(right: index == 2 ? 0 : 7),
            child: _buildHomeTab(index, sections[index]),
          )),
        )),
        const SizedBox(height: 16),
        if (homeSection == 0) ...[
          _homeSectionTitle('Мои цели', () => addHomeItem('goals')),
          if (goals.isEmpty) _emptyHomeHint('Добавь цель, к которой хочешь прийти')
          else ...goals.map((goal) => _goalTile(goal)),
        ] else if (homeSection == 1) ...[
          _homeSectionTitle('Мои достижения', () => addHomeItem('achievements')),
          if (achievements.isEmpty) _emptyHomeHint('Здесь будут твои завершённые цели и личные победы')
          else ...achievements.asMap().entries.map((entry) => _achievementTile(entry.value, () async {
            setState(() => achievements.removeAt(entry.key)); await saveData();
          })),
        ] else ...[
          _homeSectionTitle('Мои привычки', () => addHomeItem('habits')),
          if (habits.isEmpty) _emptyHomeHint('Добавь привычки, которые хочешь развивать')
          else ...habits.values.map((habit) => Container(
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(14)),
            child: ListTile(
              leading: const Icon(Icons.repeat_rounded, color: habitBlue),
              title: Text(habit.title, style: const TextStyle(color: graphite)),
              subtitle: Text(frequencyLabel(habit.frequency),
                  style: const TextStyle(color: muted, fontSize: 11)),
              trailing: Wrap(spacing: 0, children: [
                IconButton(tooltip: 'Редактировать привычку', onPressed: () => editHomeItem('habits', habit: habit), icon: const Icon(Icons.edit_outlined, color: muted, size: 19)),
                IconButton(tooltip: 'Удалить привычку', onPressed: () => deleteHabit(habit), icon: const Icon(Icons.delete_outline, color: muted, size: 19)),
              ]),
            ),
          )),
        ],
      ],
    );
  }

  Widget _buildHomeTab(int index, String label) {
    final selected = homeSection == index;
    return InkWell(
      onTap: () => setState(() { homeSection = index; openedGoal = null; }),
      borderRadius: BorderRadius.circular(14),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 5),
        decoration: BoxDecoration(
          color: selected ? buttonColor : paper,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: selected ? beige : beige.withOpacity(0.65)),
        ),
        alignment: Alignment.center,
        child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
            color: graphite)),
      ),
    );
  }

  Widget _goalTile(ProgressItem goal) {
    final progress = goal.calculatedProgress;
    return InkWell(
      onTap: () => setState(() => openedGoal = goal),
      borderRadius: BorderRadius.circular(15),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(15)),
        child: Row(children: [
          const Icon(Icons.flag_outlined, color: beige),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(goal.title, style: const TextStyle(color: graphite, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            ClipRRect(borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(value: progress / 100, minHeight: 7,
                backgroundColor: cream, color: green)),
            const SizedBox(height: 4),
            Text('${goal.steps.where((s) => s.done).length}/${goal.steps.length} задач выполнено',
                style: const TextStyle(color: muted, fontSize: 11)),
          ])),
          const SizedBox(width: 12),
          SizedBox(width: 46, height: 46,
            child: Stack(alignment: Alignment.center, children: [
              SizedBox.expand(child: CircularProgressIndicator(value: progress / 100,
                strokeWidth: 5, backgroundColor: cream, color: green)),
              Text('$progress%', style: const TextStyle(fontSize: 10,
                  color: graphite, fontWeight: FontWeight.w700)),
            ])),
          const Icon(Icons.chevron_right, color: muted),
          IconButton(tooltip: 'Редактировать цель', onPressed: () => editHomeItem('goals', goal: goal),
            icon: const Icon(Icons.edit_outlined, color: muted, size: 18)),
          IconButton(
            tooltip: 'Удалить цель',
            onPressed: () async {
              setState(() {
                goals.remove(goal);
                if (openedGoal == goal) openedGoal = null;
              });
              await saveData();
            },
            icon: const Icon(Icons.close, color: muted, size: 18),
          ),
        ]),
      ),
    );
  }

  Widget _achievementTile(ProgressItem item, VoidCallback onDelete) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(15)),
      child: Row(children: [
        const Icon(Icons.emoji_events_outlined, color: beige, size: 25),
        const SizedBox(width: 12),
        Expanded(child: Text(item.title, style: const TextStyle(
            color: graphite, fontWeight: FontWeight.w600))),
        IconButton(onPressed: onDelete, icon: const Icon(Icons.close, color: muted, size: 18)),
      ]),
    );
  }

  Widget buildGoalDetail(ProgressItem goal) {
    final progress = goal.calculatedProgress;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 20, 12),
        child: Row(children: [
          IconButton(onPressed: () => setState(() => openedGoal = null),
              icon: const Icon(Icons.arrow_back, color: graphite)),
          Expanded(child: Text(goal.title, style: const TextStyle(
              color: graphite, fontSize: 21, fontWeight: FontWeight.w600))),
          IconButton(onPressed: () => addGoalStep(goal),
              icon: const Icon(Icons.add_circle_outline, color: graphite)),
        ]),
      ),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(children: [
          Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(value: progress / 100, minHeight: 9,
                backgroundColor: paper, color: green))),
          const SizedBox(width: 12),
          Text('$progress%', style: const TextStyle(color: graphite, fontWeight: FontWeight.bold)),
        ])),
      const SizedBox(height: 18),
      Expanded(child: goal.steps.isEmpty
        ? const Center(child: Text('Добавь задачи, которые помогут достичь цели',
            style: TextStyle(color: muted)))
        : ListView(padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            children: goal.steps.asMap().entries.map((entry) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(14)),
              child: CheckboxListTile(
                value: entry.value.done,
                activeColor: green,
                title: Text(entry.value.title, style: TextStyle(color: graphite,
                    decoration: entry.value.done ? TextDecoration.lineThrough : null)),
                onChanged: (value) => toggleGoalStep(goal, entry.value, value ?? false),
                secondary: PopupMenuButton<String>(
                  onSelected: (action) {
                    if (action == 'edit') editGoalStep(goal, entry.value);
                    if (action == 'delete') deleteGoalStep(goal, entry.value);
                  },
                  itemBuilder: (context) => const [
                    PopupMenuItem(value: 'edit', child: Text('Редактировать')),
                    PopupMenuItem(value: 'delete', child: Text('Удалить')),
                  ],
                ),
              ),
            )).toList())),
    ]);
  }

  Widget _emptyHomeHint(String text) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: paper,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(text, style: const TextStyle(color: muted, fontSize: 13)),
    );
  }

  Widget _homeTextTile(String text, IconData icon, VoidCallback onDelete) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: paper,
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        leading: Icon(icon, color: beige),
        title: Text(text, style: const TextStyle(color: graphite)),
        trailing: IconButton(
          onPressed: onDelete,
          icon: const Icon(Icons.close, color: muted, size: 18),
        ),
      ),
    );
  }

  Widget buildNotesPage() {
    final topics = noteTopics.keys.toList();
    if (selectedNoteTopic != null && !noteTopics.containsKey(selectedNoteTopic)) {
      selectedNoteTopic = null;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 18, 20, 8),
          child: Text(
            'Заметки',
            style: TextStyle(
              color: graphite,
              fontSize: 28,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        SizedBox(
          height: 66,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 5),
                child: InkWell(
                  onTap: addNoteTopic,
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    width: 54,
                    decoration: BoxDecoration(
                      color: graphite,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.add, color: paper, size: 25),
                  ),
                ),
              ),
              ...topics.map((topic) {
                final selected = selectedNoteTopic == topic;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: InkWell(
                    onTap: () => setState(() => selectedNoteTopic = topic),
                    borderRadius: BorderRadius.circular(14),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      constraints: const BoxConstraints(minWidth: 90),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: selected ? buttonColor : paper,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: selected ? beige : beige.withOpacity(0.6),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        topic,
                        style: TextStyle(
                          color: graphite,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ],
          ),
        ),
        Expanded(
          child: selectedNoteTopic == null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(30),
                    child: Text(
                      topics.isEmpty
                          ? 'Нажми +, чтобы создать первую тему'
                          : 'Выбери тему или создай новую',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: muted, fontSize: 14),
                    ),
                  ),
                )
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              selectedNoteTopic!,
                              style: const TextStyle(
                                color: graphite,
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          IconButton(tooltip: 'Переименовать тему', onPressed: () => editNoteTopic(selectedNoteTopic!), icon: const Icon(Icons.edit_outlined, color: muted)),
                          IconButton(tooltip: 'Удалить тему', onPressed: () => deleteNoteTopic(selectedNoteTopic!), icon: const Icon(Icons.delete_outline, color: muted)),
                          TextButton.icon(
                            onPressed: addTopicNote,
                            icon: const Icon(Icons.add),
                            label: const Text('Новая заметка'),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: (noteTopics[selectedNoteTopic!] ?? []).isEmpty
                          ? const Center(
                              child: Text(
                                'В этой теме пока нет заметок',
                                style: TextStyle(color: muted),
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                              itemCount: noteTopics[selectedNoteTopic!]!.length,
                              itemBuilder: (context, index) {
                                final note = noteTopics[selectedNoteTopic!]![index];
                                return Container(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  padding: const EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: paper,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          note,
                                          style: const TextStyle(
                                            color: graphite,
                                            height: 1.45,
                                          ),
                                        ),
                                      ),
                                      Column(children: [
                                      IconButton(tooltip: 'Редактировать заметку', onPressed: () => editTopicNote(selectedNoteTopic!, index), icon: const Icon(Icons.edit_outlined, color: muted)),
                                      IconButton(
                                        onPressed: () async {
                                          setState(() {
                                            noteTopics[selectedNoteTopic!]!.removeAt(index);
                                          });
                                          await saveData();
                                        },
                                        icon: const Icon(
                                          Icons.delete_outline,
                                          color: muted,
                                        ),
                                      ),
                                      ]),
                                    ],
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
        ),
      ],
    );
  }

  Widget _bottomNavItem(int index, IconData icon, String label) {
    final selected = currentTab == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => currentTab = index),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: selected ? graphite : muted, size: 23),
              const SizedBox(height: 3),
              Text(
                label,
                style: TextStyle(
                  color: selected ? graphite : muted,
                  fontSize: 10,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // РЕДАКТИРОВАНИЕ ЗАДАЧИ
  Future<void> editTask(PlannerTask task) async {
    final titleController = TextEditingController(text: task.title);
    final notesController = TextEditingController(text: task.notes);
    DateTime editedDate = task.date;
    final editedDates = List<DateTime>.from(task.dates);
    TimeOfDay editedTime = task.time;
    TaskType editedType = task.type;
    String? editedCategoryId = task.categoryId;

    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: paper,
              title: const Text('Редактировать задачу'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: titleController,
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'Название задачи',
                      ),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Категория',
                      style: TextStyle(fontSize: 13, color: muted),
                    ),
                    const SizedBox(height: 8),
                    // Единый выбор: встроенные и пользовательские категории
                    // находятся в одной сетке и взаимоисключают друг друга.
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        ...TaskType.values
                            .where((type) => !hiddenBuiltinCategories.contains(type.name))
                            .map((type) => ChoiceChip(
                                  avatar: Icon(taskTypeIcon(type), size: 19, color: graphite),
                                  label: Text(type == TaskType.video
                                      ? 'Публикация'
                                      : type == TaskType.shooting
                                          ? 'Съёмка'
                                          : 'Обычная'),
                                  selected: editedCategoryId == null && editedType == type,
                                  selectedColor: taskColor(type).withValues(alpha: .4),
                                  onSelected: (_) => setDialogState(() {
                                    editedCategoryId = null;
                                    editedType = type;
                                  }),
                                )),
                        ...customCategories.map((category) => ChoiceChip(
                              avatar: categoryGlyph(category, size: 19),
                              label: Text(category.name),
                              selected: editedCategoryId == category.id,
                              selectedColor: category.color.withValues(alpha: .4),
                              onSelected: (_) => setDialogState(() {
                                editedCategoryId = category.id;
                              }),
                            )),
                      ],
                    ),
                    Align(alignment: Alignment.centerLeft, child: TextButton.icon(
                      onPressed: () async {
                        Navigator.pop(dialogContext, 'manage');
                        await manageTaskCategories();
                        if (mounted) editTask(task);
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Управление категориями'),
                    )),
                    const SizedBox(height: 18),
                    TextField(
                      controller: notesController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Заметки',
                        alignLabelWithHint: true,
                      ),
                    ),
                    const SizedBox(height: 14),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showDatePicker(context: context, initialDate: editedDates.isNotEmpty ? editedDates.last : editedDate, firstDate: DateTime(2020), lastDate: DateTime(2100));
                        if (picked != null && !editedDates.any((d) => sameDay(d, picked))) {
                          setDialogState(() => editedDates.add(DateTime(picked.year, picked.month, picked.day)));
                        }
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Добавить дату'),
                    ),
                    Wrap(spacing: 4, children: editedDates.map((d) => Chip(label: Text(fullDate(d)), onDeleted: editedDates.length > 1 ? () => setDialogState(() => editedDates.remove(d)) : null)).toList()),
                    OutlinedButton.icon(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: editedTime,
                        );
                        if (picked != null) {
                          setDialogState(() {
                            editedTime = picked;
                          });
                        }
                      },
                      icon: const Icon(Icons.access_time),
                      label: Text(
                        'Время: ${editedTime.format(context)}',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton.icon(
                  onPressed: () async {
                    final confirmed = await showDialog<bool>(
                      context: dialogContext,
                      builder: (confirmContext) => AlertDialog(
                        backgroundColor: paper,
                        title: const Text('Удалить задачу?'),
                        content: Text('«${task.title}» будет удалена без возможности восстановления.'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(confirmContext, false), child: const Text('Отмена')),
                          FilledButton(
                            style: FilledButton.styleFrom(backgroundColor: Colors.redAccent),
                            onPressed: () => Navigator.pop(confirmContext, true),
                            child: const Text('Удалить'),
                          ),
                        ],
                      ),
                    );
                    if (confirmed == true && dialogContext.mounted) {
                      Navigator.pop(dialogContext, 'delete');
                    }
                  },
                  icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                  label: const Text('Удалить', style: TextStyle(color: Colors.redAccent)),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext, 'cancel'),
                  child: const Text('Отмена'),
                ),
                FilledButton(
                  onPressed: () {
                    if (titleController.text.trim().isNotEmpty) {
                      Navigator.pop(dialogContext, 'save');
                    }
                  },
                  child: const Text('Сохранить'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == 'delete') {
      setState(() => tasks.remove(task));
      await saveData();
    } else if (result == 'save' && titleController.text.trim().isNotEmpty) {
      setState(() {
        task.title = titleController.text.trim();
        task.notes = notesController.text.trim();
        task.dates = List<DateTime>.from(editedDates);
        task.date = editedDates.first;
        task.time = editedTime;
        task.type = editedType;
        task.categoryId = editedCategoryId;
      });
      await saveData();
    }

    titleController.dispose();
    notesController.dispose();
  }

  // ЗАМЕТКИ НА ДЕНЬ
  Future<void> editDailyNote() async {
    final controller = TextEditingController(
      text: dailyNotes[dateKey(selectedDate)] ?? '',
    );

    await showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: paper,
        title: const Text('Заметки на день'),
        content: TextField(
          controller: controller,
          maxLines: 6,
          decoration: const InputDecoration(
            hintText: 'Запиши важные мысли и планы...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () {
              setState(() {
                dailyNotes[dateKey(selectedDate)] = controller.text;
              });
              Navigator.pop(dialogContext);
            },
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );

    await saveData();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: cream,
        title: Text(
          currentTab == 4
              ? 'МОЙ ПРОФИЛЬ'
              : currentTab == 3
                  ? 'ЗАМЕТКИ'
                  : (profileNicknameController.text.trim().isNotEmpty
                      ? 'Planer ${profileNicknameController.text.trim()}'
                      : 'MON PLANNER'),
          style: const TextStyle(
            letterSpacing: 1.5,
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: graphite,
          ),
        ),
        centerTitle: true,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: graphite))
          : AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: currentTab == 4
                  ? buildProfilePage()
                  : currentTab == 0
                      ? buildHomePage()
                      : currentTab == 3
                          ? buildNotesPage()
                          : buildCalendarPage(),
            ),
      bottomNavigationBar: isLoading
          ? null
          : SafeArea(
              top: false,
              maintainBottomViewPadding: true,
              child: Container(
                height: 72,
                decoration: const BoxDecoration(
                  color: paper,
                  border: Border(top: BorderSide(color: beige, width: 0.6)),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(
                  children: [
                    _bottomNavItem(0, Icons.home_outlined, 'Главная'),
                    _bottomNavItem(1, Icons.calendar_month_outlined, 'Календарь'),
                    Expanded(
                      child: InkWell(
                        onTap: addTask,
                        borderRadius: BorderRadius.circular(18),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 42,
                                height: 42,
                                decoration: BoxDecoration(
                                  color: graphite,
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: const Icon(Icons.add, color: paper, size: 27),
                              ),
                              const SizedBox(height: 2),
                              const Text(
                                'Добавить',
                                style: TextStyle(
                                  color: muted,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    _bottomNavItem(3, Icons.sticky_note_2_outlined, 'Заметки'),
                    _bottomNavItem(4, Icons.person_outline_rounded, 'Профиль'),
                  ],
                ),
              ),
            ),
    );
  }

  Widget buildCalendarPage() {
    return Column(
      children: [
        const Divider(height: 1, color: beige),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
          child: Row(
            children: [
              _buildModeTab(0, 'Ежедневно', Icons.today_outlined),
              const SizedBox(width: 8),
              _buildModeTab(1, 'Еженедельно', Icons.view_week_outlined),
              const SizedBox(width: 8),
              _buildModeTab(2, 'Ежемесячно', Icons.calendar_month_outlined),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: () => shiftDate(-1),
                icon: const Icon(Icons.chevron_left),
              ),
              Expanded(
                child: Column(
                  children: [
                    Text(
                      mode == 0
                          ? fullDate(selectedDate)
                          : mode == 1
                              ? 'Неделя'
                              : months[selectedDate.month - 1],
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w600,
                        color: graphite,
                      ),
                    ),
                    Text(
                      mode == 0
                          ? 'РАСПИСАНИЕ ДНЯ'
                          : mode == 1
                              ? '${weekStart().day} — ${weekStart().add(const Duration(days: 6)).day} ${months[weekStart().add(const Duration(days: 6)).month - 1]}'
                              : '${selectedDate.year}',
                      style: const TextStyle(
                        fontSize: 10,
                        letterSpacing: 2,
                        color: muted,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => shiftDate(1),
                icon: const Icon(Icons.chevron_right),
              ),
            ],
          ),
        ),
        Expanded(
          child: AnimatedSwitcher(
            // Короткий переход без масштабирования: меньше нагрузки на Web/iPhone.
            duration: const Duration(milliseconds: 220),
            switchInCurve: Curves.easeOut,
            switchOutCurve: Curves.easeIn,
            transitionBuilder: (child, animation) {
              return FadeTransition(
                opacity: animation,
                child: RepaintBoundary(child: child),
              );
            },
            child: KeyedSubtree(
              key: ValueKey(mode),
              child: mode == 0
                  ? buildDayView()
                  : mode == 1
                      ? buildWeekView()
                      : buildMonthView(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildModeTab(int tabMode, String label, IconData icon) {
    final isSelected = mode == tabMode;

    return Expanded(
      child: Material(
        color: isSelected ? buttonColor : paper,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () {
            if (mode != tabMode) {
              setState(() {
                mode = tabMode;
              });
            }
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isSelected ? beige : beige.withOpacity(0.65),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  icon,
                  size: 18,
                  color: graphite,
                ),
                const SizedBox(height: 5),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    label,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: graphite,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildDayView() {
    final dayTasks = tasksFor(selectedDate);
    final note = dailyNotes[dateKey(selectedDate)] ?? '';

    return ListView(
      key: const ValueKey('day'),
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 100),
      children: [
        Row(
          children: [
            const Text(
              'РАСПИСАНИЕ',
              style: TextStyle(
                color: muted,
                fontSize: 11,
                letterSpacing: 2,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            Text(
              '${dayTasks.length} задач',
              style: const TextStyle(
                color: muted,
                fontSize: 12,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (dayTasks.isEmpty)
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: paper,
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Column(
              children: [
                Icon(
                  Icons.event_note,
                  size: 36,
                  color: beige,
                ),
                SizedBox(height: 12),
                Text(
                  'Пока нет задач',
                  style: TextStyle(color: muted),
                ),
                SizedBox(height: 5),
                Text(
                  'Добавь первую задачу на этот день',
                  style: TextStyle(
                    color: muted,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          )
        else
          ...dayTasks.map((task) => taskCard(task)),
        const SizedBox(height: 18),
        const Text('ПРИВЫЧКИ НА ЭТОТ ДЕНЬ', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 1.8, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        ...habits.values.where((habit) => habitDueOn(habit, selectedDate)).map((habit) => Container(
          margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(color: paper, borderRadius: BorderRadius.circular(14)),
          child: CheckboxListTile(contentPadding: EdgeInsets.zero, dense: true, value: habitDoneFor(habit, selectedDate), activeColor: habitBlue,
            title: Text(habit.title, style: const TextStyle(color: graphite)),
            subtitle: Text(frequencyLabel(habit.frequency), style: const TextStyle(color: muted, fontSize: 11)),
            onChanged: (value) => toggleHabit(habit, selectedDate, value ?? false)),
        )),
        if (!habits.values.any((habit) => habitDueOn(habit, selectedDate)))
          const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('На этот день привычек нет', style: TextStyle(color: muted, fontSize: 12))),
        const SizedBox(height: 12),
        Row(
          children: [
            const Text(
              'ЗАМЕТКИ НА ДЕНЬ',
              style: TextStyle(
                color: muted,
                fontSize: 11,
                letterSpacing: 2,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            IconButton(
              onPressed: editDailyNote,
              icon: const Icon(
                Icons.edit_outlined,
                size: 19,
              ),
            ),
          ],
        ),
        GestureDetector(
          onTap: editDailyNote,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: paper,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              note.isEmpty
                  ? 'Нажми, чтобы добавить заметку...'
                  : note,
              style: TextStyle(
                color: note.isEmpty ? muted : graphite,
                height: 1.5,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget taskCard(PlannerTask task) {
    final color = colorForTask(task);

    return GestureDetector(
      onTap: () => editTask(task),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: paper,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withValues(alpha: 0.45),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 58,
              child: Padding(
                padding: const EdgeInsets.only(top: 3),
                child: Text(
                  task.time.format(context),
                  style: const TextStyle(
                    color: muted,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            Container(
              width: 4,
              height: task.notes.isEmpty ? 42 : 65,
              decoration: BoxDecoration(
                color: task.done ? green : color,
                borderRadius: BorderRadius.circular(5),
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.title,
                    style: TextStyle(
                      color: task.done ? muted : graphite,
                      fontWeight: FontWeight.w600,
                      decoration: task.done
                          ? TextDecoration.lineThrough
                          : null,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      categoryById(task.categoryId) == null
                          ? Icon(taskTypeIcon(task.type), size: 13, color: color)
                          : categoryGlyph(categoryById(task.categoryId)!, size: 15),
                      const SizedBox(width: 5),
                      Text(
                        labelForTask(task),
                        style: TextStyle(
                          color: color,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                  if (task.notes.isNotEmpty) ...[
                    const SizedBox(height: 7),
                    Text(
                      task.notes,
                      style: const TextStyle(
                        color: muted,
                        fontSize: 12,
                        height: 1.4,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Checkbox(
              value: task.done,
              activeColor: green,
              onChanged: (value) async {
                setState(() {
                  task.done = value ?? false;
                });
                await saveData();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildWeekView() {
    final start = weekStart();

    return ListView(
      key: const ValueKey('week'),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      children: [
        const SizedBox(height: 5),
        ...List.generate(7, (index) {
          final date = start.add(Duration(days: index));
          final dayTasks = tasksFor(date);
          final completed =
              dayTasks.where((task) => task.done).length;

          return GestureDetector(
            onTap: () {
              setState(() {
                selectedDate = date;
                mode = 0;
              });
            },
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(
                horizontal: 17,
                vertical: 16,
              ),
              decoration: BoxDecoration(
                color: sameDay(date, selectedDate)
                    ? beige.withValues(alpha: 0.3)
                    : paper,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: sameDay(date, selectedDate)
                      ? beige
                      : Colors.transparent,
                ),
              ),
              child: Row(
                children: [
                  SizedBox(
                    width: 45,
                    child: Column(
                      children: [
                        Text(
                          weekdays[index],
                          style: const TextStyle(
                            color: muted,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${date.day}',
                          style: const TextStyle(
                            color: graphite,
                            fontSize: 21,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          dayTasks.isEmpty
                              ? 'Нет задач'
                              : '$completed из ${dayTasks.length} выполнено',
                          style: const TextStyle(
                            color: muted,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 7),
                        if (dayTasks.isNotEmpty) ...[
                          LayoutBuilder(
                            builder: (context, constraints) {
                              final visible = <PlannerTask>[];
                              var rowWidth = 0.0;
                              var rowCount = 1;
                              for (final task in dayTasks) {
                                final labelLength = task.title.characters.take(10).length;
                                final chipWidth = (labelLength * 6.2 + 18).clamp(34.0, 112.0).toDouble();
                                if (rowWidth > 0 && rowWidth + chipWidth + 5 > constraints.maxWidth) {
                                  rowCount++;
                                  rowWidth = 0;
                                }
                                if (rowCount > 2) break;
                                visible.add(task);
                                rowWidth += chipWidth + 5;
                              }
                              var hidden = dayTasks.length - visible.length;
                              if (hidden > 0 && rowWidth + 34 > constraints.maxWidth && visible.isNotEmpty) {
                                visible.removeLast();
                                hidden = dayTasks.length - visible.length;
                              }
                              return Wrap(
                                spacing: 5,
                                runSpacing: 4,
                                children: [
                                  ...visible.map((task) => ConstrainedBox(
                                    constraints: const BoxConstraints(maxWidth: 112),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                                      decoration: BoxDecoration(
                                        color: task.done ? green.withValues(alpha: .18) : colorForTask(task).withValues(alpha: .48),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: ShaderMask(
                                        blendMode: BlendMode.dstIn,
                                        shaderCallback: (bounds) => const LinearGradient(
                                          begin: Alignment.centerLeft, end: Alignment.centerRight,
                                          colors: [Colors.black, Colors.black, Colors.transparent],
                                          stops: [0, .72, 1],
                                        ).createShader(bounds),
                                        child: Text(
                                          task.title.characters.take(10).toString(),
                                          maxLines: 1, softWrap: false, overflow: TextOverflow.clip,
                                          style: TextStyle(fontSize: 10, height: 1.15, color: graphite,
                                            decoration: task.done ? TextDecoration.lineThrough : null),
                                        ),
                                      ),
                                    ),
                                  )),
                                  if (hidden > 0)
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                                      decoration: BoxDecoration(color: cream, borderRadius: BorderRadius.circular(4)),
                                      child: Text('+$hidden', style: const TextStyle(fontSize: 10, color: muted, fontWeight: FontWeight.w600)),
                                    ),
                                ],
                              );
                            },
                          ),
                        ],
                        if (habits.values.any((habit) => habitDueOn(habit, date))) ...[
                          const SizedBox(height: 5),
                          Wrap(spacing: 4, children: habits.values.where((habit) => habitDueOn(habit, date)).map((habit) => Icon(
                            habitDoneFor(habit, date) ? Icons.check_circle : Icons.check_circle_outline,
                            size: 14, color: habitBlue,
                          )).toList()),
                        ],
                      ],
                    ),
                  ),
                  Text(
                    '${dayTasks.length}',
                    style: const TextStyle(
                      color: graphite,
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(
                    Icons.chevron_right,
                    color: muted,
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget buildMonthView() {
    final firstDay = DateTime(
      selectedDate.year,
      selectedDate.month,
      1,
    );
    final offset = firstDay.weekday - 1;
    final daysInMonth = DateTime(
      selectedDate.year,
      selectedDate.month + 1,
      0,
    ).day;

    return Column(
      key: const ValueKey('month'),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: weekdays.map((day) {
              return Expanded(
                child: Center(
                  child: Text(
                    day,
                    style: const TextStyle(
                      color: muted,
                      fontSize: 11,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 6,
              crossAxisSpacing: 5,
              // Немного более высокие ячейки, чтобы метки не обрезались.
              childAspectRatio: 0.8,
            ),
            itemCount: 42,
            itemBuilder: (context, index) {
              final day = index - offset + 1;
              if (day < 1 || day > daysInMonth) {
                return const SizedBox.shrink();
              }

              final date = DateTime(
                selectedDate.year,
                selectedDate.month,
                day,
              );
              final dayTasks = tasksFor(date);
              final isSelected = sameDay(date, selectedDate);
              final isToday = sameDay(date, DateTime.now());
              final dueHabits = habits.values
                  .where((habit) => habitDueOn(habit, date))
                  .toList();

              final sortedTasks = dayTasks.toList()
                ..sort((a, b) {
                  if (a.done != b.done) return a.done ? 1 : -1;
                  int priority(TaskType type) =>
                      type == TaskType.video ? 0 :
                      type == TaskType.shooting ? 1 : 2;
                  return priority(a.type).compareTo(priority(b.type));
                });

              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedDate = date;
                    mode = 0;
                  });
                },
                child: Container(
                  padding: const EdgeInsets.fromLTRB(1, 3, 1, 2),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? beige.withValues(alpha: 0.45)
                        : paper,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isToday ? green : Colors.transparent,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        '$day',
                        style: TextStyle(
                          fontSize: 12,
                          height: 1.0,
                          color: graphite,
                          fontWeight: isSelected || isToday
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                      const SizedBox(height: 3),

                      // Три миниатюрные подписи задач вместо точек.
                      ...sortedTasks.take(3).map((task) {
                        final label = task.title.characters.take(8).toString();
                        return Padding(
                          padding: EdgeInsets.zero,
                          child: SizedBox(
                            width: double.infinity,
                            height: 9,
                            child: ShaderMask(
                              blendMode: BlendMode.dstIn,
                              shaderCallback: (bounds) => const LinearGradient(
                                begin: Alignment.centerLeft,
                                end: Alignment.centerRight,
                                colors: [Colors.black, Colors.black, Colors.transparent],
                                stops: [0.0, 0.68, 1.0],
                              ).createShader(bounds),
                              child: Container(
                                alignment: Alignment.centerLeft,
                                padding: const EdgeInsets.symmetric(horizontal: 2),
                                decoration: BoxDecoration(
                                  color: task.done ? green.withValues(alpha: .16) : colorForTask(task).withValues(alpha: .42),
                                  borderRadius: BorderRadius.circular(3),
                                ),
                                child: Text(
                                  label,
                                  maxLines: 1,
                                  softWrap: false,
                                  overflow: TextOverflow.clip,
                                  style: TextStyle(
                                    fontSize: 7.5,
                                    height: 1,
                                    color: graphite,
                                    decoration: task.done ? TextDecoration.lineThrough : null,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        );
                      }),
                      if (dayTasks.length > 3)
                        Padding(
                          padding: EdgeInsets.zero,
                          child: Text(
                            '+${dayTasks.length - 3}',
                            maxLines: 1,
                            style: const TextStyle(
                              fontSize: 7,
                              height: 1,
                              color: muted,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),

                      if (dueHabits.isNotEmpty)
                        SizedBox(
                          height: 10,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: dueHabits.map((habit) {
                              return Icon(
                                habitDoneFor(habit, date)
                                    ? Icons.check
                                    : Icons.check_outlined,
                                size: 8,
                                color: habitDoneFor(habit, date) ? green : habitBlue,
                              );
                            }).toList(),
                          ),
                        ),

                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
